#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include "da_msg/rendering_msg.h"
#include <sensor_msgs/JointState.h>
#include "std_msgs/Float64.h"
#include "gazebo_msgs/ModelState.h"
#include "gazebo_msgs/LinkState.h"

#include <string>

#define init_ 1

#define X 0
#define Y 1
#define Z 2
#define ROLL 3
#define PITCH 4
#define YAW 5
#define Theta1 6
#define Theta2 7

ros::Publisher model_state_pub;
ros::Publisher joint1_position_pub;
ros::Publisher joint2_position_pub;
ros::Publisher joint3_position_pub;
ros::Publisher joint4_position_pub;

const double degree = M_PI/180;
double angle[2] = {0.0,};
double val[6]={0.0,};


void init_pose(gazebo_msgs::ModelState init_pose_val)
{
    ROS_INFO("init!");
    init_pose_val.model_name ="da_endo";
    init_pose_val.pose.position.x= 100*0.001;
    init_pose_val.pose.position.y= 100*0.001;
    init_pose_val.pose.position.z= 100*0.001;
    init_pose_val.reference_frame = "world";
    model_state_pub.publish(init_pose_val);

}

void rendering_callback(const da_msg::rendering_msg::ConstPtr& msg)
{

   for(int id=0;id<3;id++ )val[id] = msg->parameter_value[id];
   for(int id=3;id<6;id++ )val[id] = msg->parameter_value[id]*degree;
   angle[0] = msg->parameter_value[Theta1]*degree;
   angle[1] = msg->parameter_value[Theta2]*degree;


    ROS_INFO("Receive!");
}


int main(int argc, char** argv){
    ros::init(argc, argv,"tf_broadcaster");
    ros::NodeHandle n;
    ros::Rate loop_rate(1000);

    tf::TransformBroadcaster br;
    ros::Subscriber rendering_sub=n.subscribe("rendering",100,rendering_callback);

    model_state_pub = n.advertise<gazebo_msgs::ModelState>("/gazebo/set_model_state",100);
    joint1_position_pub = n.advertise<std_msgs::Float64>("/da_endo/joint1_position_controller/command",100);
    joint2_position_pub = n.advertise<std_msgs::Float64>("/da_endo/joint2_position_controller/command",100);
    joint3_position_pub = n.advertise<std_msgs::Float64>("/da_endo/joint3_position_controller/command",100);
    joint4_position_pub = n.advertise<std_msgs::Float64>("/da_endo/joint4_position_controller/command",100);
    gazebo_msgs::ModelState model_state;
    //init

    sleep(1);

    while(ros::ok()){
            ros::spinOnce();
            //init_pose(model_state);
            //position
            model_state.model_name ="da_endo";
            model_state.pose.position.x= val[0]*0.001;
            model_state.pose.position.y= val[1]*0.001;
            model_state.pose.position.z= val[2]*0.001;

            //orientation
            tf::Quaternion q;
            q = tf::createQuaternionFromRPY(val[ROLL], val[PITCH], val[YAW]);
            model_state.pose.orientation.x= q[0];
            model_state.pose.orientation.y= q[1];
            model_state.pose.orientation.z= q[2];
            model_state.pose.orientation.w= q[3];

            //pub pose
            model_state.reference_frame = "world";
            model_state_pub.publish(model_state);
            //joint pub
            std_msgs::Float64 joint_state_1, joint_state_2;
            joint_state_1.data = angle[0]/2;
            joint_state_2.data = angle[1]/2;
            joint1_position_pub.publish(joint_state_1);
            joint2_position_pub.publish(joint_state_1);
            joint3_position_pub.publish(joint_state_2);
            joint4_position_pub.publish(joint_state_2);
    }

    return 0;
}




