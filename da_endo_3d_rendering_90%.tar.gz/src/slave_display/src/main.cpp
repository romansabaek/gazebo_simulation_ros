#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include "da_msg/rendering_msg.h"
#include <sensor_msgs/JointState.h>
#include "std_msgs/Float64.h"
#include "gazebo_msgs/ModelState.h"
#include "gazebo_msgs/LinkState.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Twist.h"

#include <string>

#define init_ 1

#define X 0
#define Y 1
#define Z 2
#define ROLL 3
#define PITCH 4
#define YAW 5
#define Theta1 6
#define Theta2 7

const double degree = M_PI/180;
double angle[2] = {0.0,};
double val[6]={0.0,};




void rendering_callback(const da_msg::rendering_msg::ConstPtr& msg)
{

   for(int id=0;id<6;id++ )val[id] = msg->parameter_value[id];
   angle[0] = msg->parameter_value[Theta1];
   angle[1] = msg->parameter_value[Theta2];

    ROS_INFO("Receive!");
}


int main(int argc, char** argv){
	ros::init(argc, argv,"tf_broadcaster");
	ros::NodeHandle n;
	ros::Rate loop_rate(30);

	ros::Publisher joint_pub;
        joint_pub = n.advertise<sensor_msgs::JointState>("joint_states",1);
	tf::TransformBroadcaster br;
        ros::Subscriber rendering_sub=n.subscribe("rendering",100,rendering_callback);

	while(ros::ok()){
	        ros::spinOnce();
		sensor_msgs::JointState joint_state;
		joint_state.header.stamp = ros::Time::now();
		joint_state.name.resize(2);
		joint_state.position.resize(2);
		joint_state.name[0] ="joint1";
		joint_state.position[0] = angle[0];
		joint_state.name[1] ="joint2";
		joint_state.position[1] = angle[1];
		joint_pub.publish(joint_state);

		tf::Transform transform;
		transform.setOrigin(tf::Vector3(val[X], val[Y], val[Z]));
		tf::Quaternion q;
		q.setRPY(val[ROLL], val[PITCH], val[YAW]);
		transform.setRotation(q);
		br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "world", "base_link"));
		loop_rate.sleep();
	}

	return 0;
}




