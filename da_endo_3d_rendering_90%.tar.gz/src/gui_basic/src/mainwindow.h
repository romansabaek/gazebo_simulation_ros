#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <qtimer.h>
#include <vector>

#define X 0
#define Y 1
#define Z 2
#define ROLL 3
#define PITCH 4
#define YAW 5
#define Theta1 6
#define Theta2 7

#define NUM_PARAMETER 8

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    ros::Publisher rendering_pub;
    QTimer *timer;

    double parameter[NUM_PARAMETER];

private slots:
    void update();
    void on_Send_clicked();
    void on_Close_clicked();
    void on_stop_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
