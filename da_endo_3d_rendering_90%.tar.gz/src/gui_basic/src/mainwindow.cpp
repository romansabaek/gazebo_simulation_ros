#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "da_msg/rendering_msg.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ros::start();
    ros::NodeHandle n;
    rendering_pub = n.advertise<da_msg::rendering_msg>("rendering",100);


    ui->setupUi(this);
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    timer -> start(100); //set to 1ms

    for(int i=0;i<NUM_PARAMETER;i++) parameter[i] = 0.0;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::update(){
    ros::spinOnce();
}


void MainWindow::on_Send_clicked()
{
    parameter[X] = ui->input_x->text().toDouble();
    parameter[Y] = ui->input_y->text().toDouble();
    parameter[Z] = ui->input_z->text().toDouble();
    parameter[ROLL] = ui->input_roll->text().toDouble();
    parameter[PITCH] = ui->input_pitch->text().toDouble();
    parameter[YAW] = ui->input_yaw->text().toDouble();
    parameter[Theta1] = ui->input_theta1->text().toDouble();
    parameter[Theta2] = ui->input_theta2->text().toDouble();

    da_msg::rendering_msg Parameter_data;
    for(int val=0;val<NUM_PARAMETER;val++) Parameter_data.parameter_value.push_back(parameter[val]);
    rendering_pub.publish(Parameter_data);
    Parameter_data.parameter_value.clear();
    ui->StatusCheck->insertPlainText(" Send data!!\n");
}

void MainWindow::on_Close_clicked()
{
    ui->StatusCheck->insertPlainText(" Window Close!!\n");
    ui->StatusCheck->moveCursor(QTextCursor::End);
    this->close();
}

void MainWindow::on_stop_clicked()
{
    ui->StatusCheck->insertPlainText(" stop pose!!\n");
    da_msg::rendering_msg start_pose;
    start_pose.stop = 1;
    rendering_pub.publish(start_pose);
}
