sudo apt-get install ros-kinetic-kdl-* -y
sudo apt-get install ros-kinetic-ompl -y
sudo apt-get install ros-kinetic-trac* -y
sudo apt-get install ros-kinetic-moveit* -y
 
